import simpy
import random
import streamlit as st
import pandas as pd
import plotly.express as px

st.set_page_config(layout="wide", page_title="Havalimanı Simülasyonu PRO")

st.title("Havalimanı Güvenlik ve Pasaport Kontrol Sistemi Darboğaz Analizi")
st.markdown("---")

# --- PARAMETRE PANELİ ---
st.sidebar.header("⚙️ Simülasyon Ayarları")
p1_sec_staff = st.sidebar.slider("Güvenlik Görevlisi Sayısı", 1, 10, 3)
p2_pass_staff = st.sidebar.slider("Pasaport Memuru Sayısı", 1, 10, 2)
p3_arrival_freq = st.sidebar.slider("Baz Yolcu Geliş Aralığı (Dk)", 1, 10, 3)

# 🌟 YENİ PARAMETRE: MEVSİMSELLİK VE DÖNEM SEÇİMİ
st.sidebar.markdown("---")
st.sidebar.subheader("📅 Dönemsel Yoğunluk (Mevsimsellik)")
season = st.sidebar.selectbox(
    "Simülasyon Dönemi", 
    ["Normal Sezon", "Bayram Tatili (Aşırı Yoğun)", "Yaz Tatili (Yoğun)", "Düşük Sezon (Sakin)"]
)

p4_vip_prob = st.sidebar.slider("VIP Yolcu Olasılığı (%)", 0, 100, 15)
p5_visa_prob = st.sidebar.slider("Vize Sorunu Olasılığı (%)", 0, 100, 30)
p6_sim_duration = st.sidebar.number_input("Simülasyon Süresi (Dk)", value=120)

data_log = []

class Airport:
    def __init__(self, env, n_sec, n_pass):
        self.env = env
        self.security = simpy.PriorityResource(env, n_sec)
        self.passport = simpy.PriorityResource(env, n_pass)

    def security_process(self):
        yield self.env.timeout(random.uniform(2, 4))

    def passport_process(self, has_visa_issue):
        duration = random.uniform(3, 6)
        if has_visa_issue:
            duration += random.uniform(5, 10)
        yield self.env.timeout(duration)

def passenger(env, name, airport, is_vip, has_visa_issue):
    arrival = env.now
    prio = 0 if is_vip else 1
    
    # 1. GÜVENLİK
    with airport.security.request(priority=prio) as req:
        yield req
        wait_sec = env.now - arrival
        yield env.process(airport.security_process())
    
    # 2. PASAPORT
    post_sec = env.now
    with airport.passport.request(priority=prio) as req:
        yield req
        wait_pass = env.now - post_sec
        yield env.process(airport.passport_process(has_visa_issue))
    
    total_time = env.now - arrival
    data_log.append({
        "Yolcu": name,
        "Tip": "VIP" if is_vip else "Standart",
        "Vize Sorunu": "Var" if has_visa_issue else "Yok",
        "Güv. Bekleme": round(wait_sec, 2),
        "Pasaport Bekleme": round(wait_pass, 2),
        "Toplam Süre": round(total_time, 2)
    })

def run_sim(env, n_sec, n_pass, chosen_season):
    airport = Airport(env, n_sec, n_pass)
    p_id = 1
    while True:
        # 🌟 MEVSİMSELLİK MANTIĞI: Seçilen döneme göre geliş sıklığını çarpanla değiştiriyoruz
        # Yolcu geliş aralığı küçüldükçe (örn: 0.5 dk) sisteme daha sık ve çok insan gelir.
        if chosen_season == "Bayram Tatili (Aşırı Yoğun)":
            current_arrival_freq = p3_arrival_freq * 0.3  # %70 daha sık yolcu gelir
        elif chosen_season == "Yaz Tatili (Yoğun)":
            current_arrival_freq = p3_arrival_freq * 0.6  # %40 daha sık yolcu gelir
        elif chosen_season == "Düşük Sezon (Sakin)":
            current_arrival_freq = p3_arrival_freq * 1.5  # %50 daha seyrek yolcu gelir
        else:
            current_arrival_freq = p3_arrival_freq  # Normal akış
            
        yield env.timeout(random.expovariate(1.0 / current_arrival_freq))
        is_vip = random.random() < (p4_vip_prob / 100.0)
        has_visa = random.random() < (p5_visa_prob / 100.0)
        env.process(passenger(env, f"P-{p_id}", airport, is_vip, has_visa))
        p_id += 1

if st.button("🚀 Simülasyonu Başlat ve Analiz Et"):
    data_log = [] # Temizle
    env = simpy.Environment()
    # run_sim fonksiyonuna seçilen sezonu gönderiyoruz
    env.process(run_sim(env, p1_sec_staff, p2_pass_staff, season))
    env.run(until=p6_sim_duration)

    if data_log:
        df = pd.DataFrame(data_log)
        
        # --- METRİKLER ---
        c1, c2, c3, c4 = st.columns(4)
        c1.metric("Toplam Yolcu", len(df))
        avg_wait = df["Toplam Süre"].mean()
        c2.metric("Ort. İşlem Süresi", f"{avg_wait:.2f} dk")
        
        # DARBOĞAZ TESPİTİ
        sec_avg = df["Güv. Bekleme"].mean()
        pass_avg = df["Pasaport Bekleme"].mean()
        bottleneck = "Pasaport" if pass_avg > sec_avg else "Güvenlik"
        c3.metric("Kritik Darboğaz", bottleneck)
        c4.metric("Seçilen Dönem", season) # Hangi sezonda olduğumuzu ekranda gösteriyoruz

        # --- GRAFİKLER ---
        col_left, col_right = st.columns(2)
        
        with col_left:
            st.subheader("📍 Yolcu Tipi Bazlı Bekleme Süreleri")
            fig1 = px.box(df, x="Tip", y="Toplam Süre", color="Tip", points="all")
            st.plotly_chart(fig1, use_container_width=True)

        with col_right:
            st.subheader("⚠️ Darboğaz Analizi (Ort. Bekleme)")
            wait_df = pd.DataFrame({
                "Birim": ["Güvenlik", "Pasaport"],
                "Bekleme Süresi": [sec_avg, pass_avg]
            })
            fig2 = px.bar(wait_df, x="Birim", y="Bekleme Süresi", color="Birim")
            st.plotly_chart(fig2, use_container_width=True)

        st.subheader("📋 Tüm Detaylı Kayıtlar")
        st.dataframe(df, use_container_width=True)
    else:
        st.error("Hiç veri üretilemedi, lütfen süreyi artırın.")